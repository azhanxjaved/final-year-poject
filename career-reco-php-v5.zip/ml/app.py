# ml/app.py
# Simple AI service: logistic regression on engineered features.
# Features per (user, career):
#   - interest_overlap (int)
#   - skill_overlap (int)
#   - personality_match (0/1)
# Label: like (1) if rating>=4, else 0.
from flask import Flask, request, jsonify
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import NotFittedError
import numpy as np
import joblib
import os

MODEL_PATH = os.environ.get("MODEL_PATH", "model.joblib")
app = Flask(__name__)

def load_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    # default unfitted model
    return LogisticRegression(max_iter=1000)

model = load_model()

@app.post("/predict")
def predict():
    global model
    try:
        X = np.array(request.json.get("X", []), dtype=float)
        if X.size == 0:
            return jsonify({"scores": []})
        # proba of class 1 (liked)
        try:
            proba = model.predict_proba(X)[:, 1]
        except NotFittedError:
            # If not fitted, return heuristic fallback based on simple weights
            proba = (X[:,0]*0.4 + X[:,1]*0.4 + X[:,2]*0.2) / max(1.0, X.max(initial=1))
            proba = np.clip(proba, 0, 1)
        return jsonify({"scores": proba.tolist()})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.post("/fit")
def fit():
    global model
    data = request.json or {}
    X = np.array(data.get("X", []), dtype=float)
    y = np.array(data.get("y", []), dtype=int)
    if X.shape[0] == 0 or y.shape[0] == 0 or X.shape[0] != y.shape[0]:
        return jsonify({"error": "Bad training data"}), 400
    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)
    joblib.dump(model, MODEL_PATH)
    return jsonify({"status": "ok", "n": int(X.shape[0])})

@app.get("/health")
def health():
    try:
        # check fitted
        getattr(model, "coef_")
        status = "fitted"
    except Exception:
        status = "unfitted"
    return jsonify({"ok": True, "status": status})
    
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)

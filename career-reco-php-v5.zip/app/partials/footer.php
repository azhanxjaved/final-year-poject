<?php
// app/partials/footer.php
?>
</main>
<footer class="footer">
  <div class="container">© 2025 CareerRec<nav><a href="/privacy.php">Privacy</a> · <a href="/terms.php">ToS</a> · <a href="/retention.php">Data Retention</a> · <a href="/metrics.php">Metrics</a></nav>
  </div>
</footer>
</body>
</html>

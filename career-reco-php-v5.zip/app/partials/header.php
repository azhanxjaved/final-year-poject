<?php
// app/partials/header.php
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Career Recommendation System</title>
  <link rel="stylesheet" href="/assets/styles.css">
  <script defer src="/assets/autosave.js"></script>
</head>
<body>
<header class="topbar">
  <div class="container">
    <div class="brand"><a href="/dashboard.php">CareerRec</a></div>
    <nav>
      <?php if (!empty($_SESSION['user'])): ?>
        <a href="/dashboard.php">Dashboard</a>
        <a href="/assessment_quiz.php">Assessment</a>
        <a href="/recommendations.php">Recommendations</a>
        <a href="/profile.php">Profile</a>
        <?php if (($_SESSION['user']['role'] ?? 'user') === 'admin'): ?>
            <a href="/admin_dashboard.php">Admin</a><a href="/admin_questions.php">Questions</a><a href="/admin_careers.php">Careers</a><a href="/admin_retrain.php">Retrain</a><a href="/admin_metrics.php">Metrics</a>
        <?php endif; ?>
        <a href="/logout.php">Logout</a>
      <?php else: ?>
        <a href="/login.php">Login</a>
        <a class="btn" href="/register.php">Sign up</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">

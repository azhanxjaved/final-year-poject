<?php
// app/ai.php
function ai_compute_features(array $assessment, array $career): array {
    $interests = json_decode($assessment['interests'] ?? '[]', true) ?: [];
    $skills = json_decode($assessment['skills'] ?? '[]', true) ?: [];
    $personality = $assessment['personality'] ?? '';
    $c_tags = json_decode($career['tags'] ?? '[]', true) ?: [];
    $c_skills = json_decode($career['skills_required'] ?? '[]', true) ?: [];

    $interest_overlap = 0;
    foreach ($interests as $i) if (in_array($i, $c_tags)) $interest_overlap++;

    $skill_overlap = 0;
    foreach ($skills as $s) if (in_array($s, $c_skills)) $skill_overlap++;

    $personality_match = ($personality && in_array($personality, $c_tags)) ? 1 : 0;

    return [$interest_overlap, $skill_overlap, $personality_match];
}

function ai_predict_scores(array $assessment, array $careers): ?array {
    $X = [];
    foreach ($careers as $c) { $X[] = ai_compute_features($assessment, $c); }
    $payload = json_encode(['X'=>$X]);
    $ch = curl_init('http://127.0.0.1:5000/predict');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_TIMEOUT, 1);
    $res = curl_exec($ch);
    if ($res === false) return null;
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200) return null;
    $json = json_decode($res, true);
    if (!$json || !isset($json['scores'])) return null;
    return $json['scores'];
}

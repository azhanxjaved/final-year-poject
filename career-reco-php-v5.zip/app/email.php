<?php
// app/email.php
function send_mail_simple($to, $subject, $body) {
    $headers = "MIME-Version: 1.0\r\nContent-type:text/plain;charset=UTF-8\r\n";
    $headers .= "From: CareerRec <no-reply@localhost>";
    return mail($to, $subject, $body, $headers);
}

function create_verification($pdo, $user_id) {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time()+3600*24);
    $st = $pdo->prepare("INSERT INTO email_verifications(user_id, token, expires_at) VALUES (?,?,?)");
    $st->execute([$user_id, $token, $expires]);
    return $token;
}

function create_password_reset($pdo, $user_id) {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time()+3600);
    $st = $pdo->prepare("INSERT INTO password_resets(user_id, token, expires_at) VALUES (?,?,?)");
    $st->execute([$user_id, $token, $expires]);
    return $token;
}

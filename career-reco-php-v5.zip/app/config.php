<?php
// config.php
// Edit DB credentials as needed.
$DB_HOST = getenv('DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('DB_NAME') ?: 'career_rec';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASS') ?: '';

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    die("DB connection failed: " . htmlspecialchars($e->getMessage()));
}

session_start();
// Security headers
if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: geolocation=(), microphone=()');
    header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;");
}

// Simple session rate limiting (per-route, per-minute)
$__k = 'rate:' . ($_SERVER['SCRIPT_NAME'] ?? 'unknown');
$now = time();
if (!isset($_SESSION['__rate'][$__k])) {
    $_SESSION['__rate'][$__k] = ['t'=>$now, 'n'=>0];
}
$bucket = &$_SESSION['__rate'][$__k];
if ($now - $bucket['t'] >= 60) { $bucket = ['t'=>$now, 'n'=>0]; }
$bucket['n']++;
if ($bucket['n'] > 120) { // 120 req/min per session per route
    http_response_code(429);
    die('Too Many Requests');
}


function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_check($token) {
    return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}
function require_login() {
    if (empty($_SESSION['user'])) {
        header('Location: /login.php');
        exit;
    }
}
function is_admin() {
    return !empty($_SESSION['user']) && ($_SESSION['user']['role'] ?? 'user') === 'admin';
}
?>
<?php
// app/labor.php
// Replace with real API (e.g., BLS, Indeed/RapidAPI). This stub reads local JSON.
function labor_get_stats($title) {
    $map = [
        'Software Engineer'=>['median_salary'=>110000,'trend'=>'rising'],
        'Data Analyst'=>['median_salary'=>80000,'trend'=>'stable'],
        'UI/UX Designer'=>['median_salary'=>85000,'trend'=>'rising'],
        'Network Engineer'=>['median_salary'=>90000,'trend'=>'stable'],
        'Digital Marketer'=>['median_salary'=>70000,'trend'=>'volatile'],
    ];
    return $map[$title] ?? ['median_salary'=>null,'trend'=>null];
}

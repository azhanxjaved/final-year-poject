<?php
// app/audit.php
function audit_log($pdo, $action, $meta = null) {
    $uid = $_SESSION['user']['id'] ?? null;
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? null;
    $st = $pdo->prepare("INSERT INTO audit_logs(user_id, action, meta, ip, ua) VALUES (?,?,?,?,?)");
    $st->execute([$uid, $action, $meta ? json_encode($meta) : null, $ip, $ua]);
}

<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/audit.php';

while (true) {
    $pdo->beginTransaction();
    $st = $pdo->prepare("SELECT * FROM jobs WHERE status='queued' AND run_after<=NOW() ORDER BY id ASC LIMIT 1 FOR UPDATE SKIP LOCKED");
    $st->execute();
    $job = $st->fetch();
    if (!$job) { $pdo->commit(); sleep(5); continue; }
    $pdo->prepare("UPDATE jobs SET status='running', attempts=attempts+1 WHERE id=?")->execute([$job['id']]);
    $pdo->commit();

    $ok = true; $error = null;
    try {
        $payload = json_decode($job['payload'], true);
        if ($job['type'] === 'email_report') {
            // Generate CSV and send (left as stub)
            // ...
        }
        // Add more job types as needed
    } catch (Throwable $e) { $ok = False; $error = $e->getMessage(); }

    if ($ok) {
        $pdo->prepare("UPDATE jobs SET status='done' WHERE id=?")->execute([$job['id']]);
    } else {
        $pdo->prepare("UPDATE jobs SET status='failed', last_error=? WHERE id=?")->execute([$error, $job['id']]);
    }
}

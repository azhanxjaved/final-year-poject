
USE career_rec;
CREATE INDEX IF NOT EXISTS idx_assess_user ON assessments(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_fb_user_career ON feedback(user_id, career_id, created_at);
CREATE INDEX IF NOT EXISTS idx_recs_user ON recommendations(user_id, created_at);

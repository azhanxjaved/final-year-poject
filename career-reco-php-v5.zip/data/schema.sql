
-- MySQL schema for Career Recommendation MVP
CREATE DATABASE IF NOT EXISTS career_rec CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE career_rec;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS assessments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  interests JSON,
  skills JSON,
  personality VARCHAR(40),
  goals TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS careers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  short_desc VARCHAR(300) DEFAULT '',
  skills_required JSON,
  tags JSON,
  roles VARCHAR(300) DEFAULT '',
  education VARCHAR(200) DEFAULT '',
  growth VARCHAR(120) DEFAULT ''
);

CREATE TABLE IF NOT EXISTS recommendations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  career_id INT NOT NULL,
  score INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  career_id INT NOT NULL,
  rating TINYINT NOT NULL,
  comment VARCHAR(400) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE CASCADE
);

-- Seed some careers
INSERT INTO careers (title, short_desc, skills_required, tags, roles, education, growth) VALUES
('Software Engineer','Builds and maintains software systems',
  JSON_ARRAY('php','python','sql'),
  JSON_ARRAY('programming','analytical'),
  'Backend Developer, Full-stack Engineer',
  'BS CS or equivalent experience','High demand'),
('Data Analyst','Analyzes data to derive insights',
  JSON_ARRAY('excel','sql','python'),
  JSON_ARRAY('data','analytical'),
  'BI Analyst, Reporting Analyst',
  'BS Stats/CS/Business Analytics','Strong'),
('UI/UX Designer','Designs user interfaces and experiences',
  JSON_ARRAY('figma','communication'),
  JSON_ARRAY('design','creative'),
  'Product Designer, UX Researcher',
  'Design degree or portfolio','Growing'),
('Network Engineer','Maintains networks and hardware',
  JSON_ARRAY('sql','communication'),
  JSON_ARRAY('hardware','analytical'),
  'Network Admin, Systems Engineer',
  'BS IT/Networking certifications','Stable'),
('Digital Marketer','Plans and runs marketing campaigns',
  JSON_ARRAY('communication','excel'),
  JSON_ARRAY('business','social','creative'),
  'SEO Specialist, Performance Marketer',
  'BBA/Marketing or experience','High variability');

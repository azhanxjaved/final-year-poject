
USE career_rec;

CREATE TABLE IF NOT EXISTS questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  text VARCHAR(300) NOT NULL,
  category VARCHAR(60) NOT NULL,
  tag VARCHAR(60) NOT NULL, -- e.g., programming, data, design, business, hardware, teaching, analytical, creative, social
  weight INT NOT NULL DEFAULT 1,
  type ENUM('likert','single','multi') NOT NULL DEFAULT 'likert',
  options_json JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assessment_answers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  assessment_id INT NOT NULL,
  question_id INT NOT NULL,
  answer VARCHAR(160) NOT NULL,
  score INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- Seed ~12 Likert questions (1-5) mapped to tags
INSERT INTO questions (text, category, tag, weight, type) VALUES
('I enjoy building or fixing software.', 'interest', 'programming', 2, 'likert'),
('I like finding patterns in data.', 'interest', 'data', 2, 'likert'),
('I care about layout, typography, and usability.', 'interest', 'design', 2, 'likert'),
('I enjoy crafting marketing messages or campaigns.', 'interest', 'business', 2, 'likert'),
('I like working with routers, cables, and servers.', 'interest', 'hardware', 2, 'likert'),
('I enjoy teaching or explaining complex topics.', 'interest', 'teaching', 2, 'likert'),
('I prefer analytical, logical problem solving.', 'trait', 'analytical', 2, 'likert'),
('I prefer brainstorming and visual ideas.', 'trait', 'creative', 2, 'likert'),
('I get energy from working with people.', 'trait', 'social', 2, 'likert'),
('I know basic SQL or want to learn it.', 'skill', 'sql', 1, 'likert'),
('I know basic PHP or want to learn it.', 'skill', 'php', 1, 'likert'),
('I am comfortable with spreadsheets (Excel/Sheets).', 'skill', 'excel', 1, 'likert');

<?php
use PHPUnit\Framework\TestCase;

final class SmokeTest extends TestCase {
    public function testTruth(): void {
        $this->assertTrue(true);
    }
}

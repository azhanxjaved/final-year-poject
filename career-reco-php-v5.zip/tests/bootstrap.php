<?php
// tests/bootstrap.php
// Minimal bootstrap

<?php include __DIR__ . '/../app/partials/header.php'; ?>
<div class="card"><h1>Data Retention</h1><p class="muted">Assessment data is retained while your account is active and deleted upon request. Logs retained 90 days.</p></div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

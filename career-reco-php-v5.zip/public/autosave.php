<?php
require __DIR__ . '/../app/config.php';
require_login();
$data = json_decode(file_get_contents('php://input'), true);
$k = $data['k'] ?? null; $v = $data['v'] ?? null;
if ($k && $v) {
    $_SESSION['quiz'][$k] = (int)$v;
    // do not persist to DB here to avoid write amplification; saved via Save button
    http_response_code(204);
    exit;
}
http_response_code(400);

<?php
require __DIR__ . '/../app/config.php';
require_login();
require_once __DIR__ . '/../app/email.php';
require_once __DIR__ . '/../app/audit.php';

$uid = $_SESSION['user']['id'];
$st = $pdo->prepare("SELECT email_verified,email FROM users WHERE id=?");
$st->execute([$uid]);
$u = $st->fetch();
if ($u && !$u['email_verified']) {
    $token = create_verification($pdo, $uid);
    $link = (isset($_SERVER['HTTPS'])?'https':'http')."://".$_SERVER['HTTP_HOST']."/verify.php?token=".$token;
    send_mail_simple($u['email'], "Verify your email", "Click to verify: ".$link);
    audit_log($pdo, 'verify_sent');
}
header('Location: /profile.php');

<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/audit.php';

if (!empty($_SESSION['user'])) { header('Location: /dashboard.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    $st = $pdo->prepare("SELECT id,name,email,password_hash,role FROM users WHERE email=?");
    $st->execute([$email]);
    $u = $st->fetch();
    if (!$u || !password_verify($pass, $u['password_hash'])) {
        $err = "Invalid credentials.";
        audit_log($pdo, 'login_failed', ['email'=>$email]);
    } else {
        $_SESSION['user'] = $u;
        audit_log($pdo, 'login_success');
        header('Location: /dashboard.php');
        exit;
    }
}
include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Login</h1>
  <?php if (isset($_GET['new'])): ?><p class="muted">Account created. You can login now.</p><?php endif; ?>
  <?php if (!empty($err)): ?><p class="muted"><?=$err?></p><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <div style="margin-top:12px"><button type="submit">Login</button></div>
  </form>
  <p class="muted">No account? <a href="/register.php">Sign up</a></p>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

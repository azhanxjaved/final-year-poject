document.addEventListener('change', function(e){
  if(e.target.name && e.target.name.startsWith('q_')){
    // best-effort autosave via fetch
    try{
      fetch('/autosave.php', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({k:e.target.name, v:e.target.value})});
    }catch(e){}
  }
});
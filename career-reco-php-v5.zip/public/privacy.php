<?php include __DIR__ . '/../app/partials/header.php'; ?>
<div class="card"><h1>Privacy Policy</h1><p class="muted">We collect account and assessment data to provide recommendations. You can delete your account by contacting support.</p></div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

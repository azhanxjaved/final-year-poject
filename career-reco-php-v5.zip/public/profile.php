<?php
require __DIR__ . '/../app/config.php';
require_login();
$uid = $_SESSION['user']['id'];

$st = $pdo->prepare("SELECT id,name,email,role,created_at,last_login FROM users WHERE id=?");
$st->execute([$uid]);
$u = $st->fetch();

$st = $pdo->prepare("SELECT created_at FROM assessments WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
$st->execute([$uid]);
$last_assess = $st->fetch()['created_at'] ?? null;

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Profile</h1>
  <p><strong>Name:</strong> <?=htmlspecialchars($u['name'])?></p>
  <p><strong>Email:</strong> <?=htmlspecialchars($u['email'])?></p>
  <p><strong>Role:</strong> <?=htmlspecialchars($u['role'])?></p>
  <p><strong>Member since:</strong> <?=htmlspecialchars($u['created_at'])?></p>
  <p><strong>Last login:</strong> <?=htmlspecialchars($u['last_login'])?></p>
  <p><strong>Last assessment:</strong> <?=htmlspecialchars($last_assess ?? '—')?></p>
<p><a href="/verify_send.php">Send verification email</a> · <a href="/forgot.php">Forgot password</a></p>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

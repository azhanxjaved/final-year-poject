<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/audit.php';

$token = $_GET['token'] ?? '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $token = $_POST['token'] ?? '';
    $pass = $_POST['password'] ?? '';
    $st = $pdo->prepare("SELECT user_id, expires_at, used FROM password_resets WHERE token=?");
    $st->execute([$token]);
    $row = $st->fetch();
    if ($row && !$row['used'] && strtotime($row['expires_at']) > time()) {
        $pdo->beginTransaction();
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash, $row['user_id']]);
        $pdo->prepare("UPDATE password_resets SET used=1 WHERE token=?")->execute([$token]);
        $pdo->commit();
        audit_log($pdo, 'reset_ok', ['uid'=>$row['user_id']]);
        echo "Password updated. You may login now.";
        exit;
    } else {
        $err = "Invalid or expired token.";
    }
}

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Reset Password</h1>
  <?php if (!empty($err)): ?><p><?=$err?></p><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <input type="hidden" name="token" value="<?=htmlspecialchars($token)?>">
    <label>New password</label><input type="password" name="password" minlength="8" required>
    <button type="submit">Update</button>
  </form>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die("Forbidden"); }

$users = $pdo->query("SELECT COUNT(*) c FROM users")->fetch()['c'] ?? 0;
$assess = $pdo->query("SELECT COUNT(*) c FROM assessments")->fetch()['c'] ?? 0;
$recs = $pdo->query("SELECT COUNT(*) c FROM recommendations")->fetch()['c'] ?? 0;
$fb = $pdo->query("SELECT COUNT(*) c FROM feedback")->fetch()['c'] ?? 0;
$careers = $pdo->query("SELECT COUNT(*) c FROM careers")->fetch()['c'] ?? 0;
$qs = $pdo->query("SELECT COUNT(*) c FROM questions")->fetch()['c'] ?? 0;

// average match score per career
$avg = $pdo->query("
  SELECT c.title, ROUND(AVG(r.score),1) avg_score, COUNT(*) n
  FROM recommendations r JOIN careers c ON c.id=r.career_id
  GROUP BY c.id ORDER BY avg_score DESC LIMIT 10
")->fetchAll();

include __DIR__ . '/../app/partials/header.php';
?>
<div class="grid">
  <div class="card"><h3>Users</h3><p><span class="badge"><?=$users?></span></p></div>
  <div class="card"><h3>Assessments</h3><p><span class="badge"><?=$assess?></span></p></div>
  <div class="card"><h3>Recommendations</h3><p><span class="badge"><?=$recs?></span></p></div>
  <div class="card"><h3>Feedback</h3><p><span class="badge"><?=$fb?></span></p></div>
  <div class="card"><h3>Careers</h3><p><span class="badge"><?=$careers?></span></p></div>
  <div class="card"><h3>Questions</h3><p><span class="badge"><?=$qs?></span></p></div>
</div>

<div class="card">
  <h2>Top Careers by Avg Match</h2>
  <table class="table">
    <tr><th>Career</th><th>Avg Match</th><th>Samples</th></tr>
    <?php foreach ($avg as $row): ?>
      <tr><td><?=htmlspecialchars($row['title'])?></td><td><?=$row['avg_score']?>%</td><td><?=$row['n']?></td></tr>
    <?php endforeach; ?>
  </table>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

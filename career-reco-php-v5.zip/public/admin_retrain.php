<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die('Forbidden'); }
require_once __DIR__ . '/../app/ai.php';

$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    // Build training set from feedback joined with latest assessment
    $rows = $pdo->query("
        SELECT f.user_id, f.career_id, f.rating, a.id AS assess_id, a.interests, a.skills, a.personality,
               c.tags, c.skills_required
        FROM feedback f
        JOIN careers c ON c.id=f.career_id
        JOIN (
           SELECT x.* FROM assessments x
           JOIN (SELECT user_id, MAX(created_at) mx FROM assessments GROUP BY user_id) t
           ON t.user_id=x.user_id AND t.mx=x.created_at
        ) a ON a.user_id=f.user_id
    ")->fetchAll();

    $X = []; $y = [];
    foreach ($rows as $r) {
        $feat = ai_compute_features($r, $r);
        $X[] = $feat;
        $y[] = ((int)$r['rating'] >= 4) ? 1 : 0;
    }

    $payload = json_encode(['X'=>$X,'y'=>$y]);
    $ch = curl_init('http://127.0.0.1:5000/fit');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code === 200) $msg = "Model retrained.";
    else $msg = "Training failed or AI service offline.";
}

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Admin · Retrain AI Model</h1>
  <p class="muted">Trains on user feedback (ratings ≥4 are positive).</p>
  <?php if ($msg): ?><p><?=$msg?></p><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <button type="submit">Retrain</button>
  </form>
  <p class="muted">Ensure the AI service is running: <code>python ml/app.py</code></p>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

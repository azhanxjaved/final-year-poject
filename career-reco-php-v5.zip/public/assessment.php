<?php
require __DIR__ . '/../app/config.php';
require_login();

$uid = $_SESSION['user']['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $interests = $_POST['interests'] ?? [];
    $skills = $_POST['skills'] ?? [];
    $personality = $_POST['personality'] ?? 'balanced';
    $goals = trim($_POST['goals'] ?? '');

    $st = $pdo->prepare("INSERT INTO assessments(user_id, interests, skills, personality, goals) VALUES (?,?,?,?,?)");
    $st->execute([$uid, json_encode($interests), json_encode($skills), $personality, $goals]);
    header("Location: /recommendations.php?from=assessment");
    exit;
}

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Career Assessment</h1>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <label>Interests (choose some)</label>
    <select name="interests[]" multiple size="6">
      <option value="programming">Programming</option>
      <option value="data">Data & Analytics</option>
      <option value="design">Design & UX</option>
      <option value="business">Business & Marketing</option>
      <option value="hardware">Hardware/Networking</option>
      <option value="teaching">Teaching/Training</option>
    </select>

    <label>Skills (choose some)</label>
    <select name="skills[]" multiple size="6">
      <option value="python">Python</option>
      <option value="php">PHP</option>
      <option value="sql">SQL</option>
      <option value="excel">Excel</option>
      <option value="figma">Figma</option>
      <option value="communication">Communication</option>
    </select>

    <label>Personality</label>
    <select name="personality">
      <option value="balanced">Balanced</option>
      <option value="analytical">Analytical</option>
      <option value="creative">Creative</option>
      <option value="social">Social</option>
    </select>

    <label>Goals (optional)</label>
    <textarea name="goals" rows="3" placeholder="e.g., remote job, high salary, startup, research"></textarea>

    <div style="margin-top:12px"><button type="submit">Submit Assessment</button></div>
  </form>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

<?php include __DIR__ . '/../app/partials/header.php'; ?>
<div class="card"><h1>Terms of Service</h1><p class="muted">Use at your own risk. No guarantees of employment outcomes.</p></div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

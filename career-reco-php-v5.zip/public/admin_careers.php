<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die("Forbidden"); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $title = trim($_POST['title'] ?? '');
    $short = trim($_POST['short_desc'] ?? '');
    $skills = array_filter(array_map('trim', explode(',', $_POST['skills_required'] ?? '')));
    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'] ?? '')));
    $roles = trim($_POST['roles'] ?? '');
    $education = trim($_POST['education'] ?? '');
    $growth = trim($_POST['growth'] ?? '');
    if ($title) {
        $st = $pdo->prepare("INSERT INTO careers(title,short_desc,skills_required,tags,roles,education,growth) VALUES(?,?,?,?,?,?,?)");
        $st->execute([$title,$short,json_encode($skills),json_encode($tags),$roles,$education,$growth]);
    }
    header("Location: /admin_careers.php");
    exit;
}

$rows = $pdo->query("SELECT * FROM careers ORDER BY id DESC")->fetchAll();

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Admin · Careers</h1>
  <form method="post" class="card">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <label>Title</label><input name="title" required>
    <label>Short description</label><input name="short_desc">
    <label>Required skills (comma separated)</label><input name="skills_required" placeholder="php, sql, python">
    <label>Tags & traits (comma separated)</label><input name="tags" placeholder="programming, analytical, creative">
    <label>Typical roles</label><input name="roles" placeholder="e.g., Backend developer, API engineer">
    <label>Education</label><input name="education" placeholder="e.g., BS CS or equivalent experience">
    <label>Growth</label><input name="growth" placeholder="e.g., High demand, strong salary growth">
    <button type="submit">Add career</button>
  </form>
  <h2>Existing careers</h2>
  <table class="table">
    <tr><th>ID</th><th>Title</th><th>Tags</th><th>Skills</th></tr>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?=$r['id']?></td>
        <td><?=htmlspecialchars($r['title'])?></td>
        <td><?=htmlspecialchars(implode(', ', json_decode($r['tags'], true) ?: []))?></td>
        <td><?=htmlspecialchars(implode(', ', json_decode($r['skills_required'], true) ?: []))?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

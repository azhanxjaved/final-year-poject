<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/audit.php';

audit_log($pdo, 'logout');
session_destroy();
header('Location: /login.php');

<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die("Forbidden"); }

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="recommendations.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, ['user_email','career_title','score','created_at']);

$st = $pdo->query("
    SELECT u.email, c.title, r.score, r.created_at
    FROM recommendations r
    JOIN users u ON u.id=r.user_id
    JOIN careers c ON c.id=r.career_id
    ORDER BY r.created_at DESC
");
while ($row = $st->fetch(PDO::FETCH_NUM)) {
    fputcsv($out, $row);
}
fclose($out);
exit;

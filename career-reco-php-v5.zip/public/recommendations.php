<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/ai.php';
require_once __DIR__ . '/../app/labor.php';
require_login();
$uid = $_SESSION['user']['id'];

// get latest assessment
$st = $pdo->prepare("SELECT * FROM assessments WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
$st->execute([$uid]);
$assess = $st->fetch();

include __DIR__ . '/../app/partials/header.php';

if (!$assess): ?>
  <div class="card"><p>No assessment found. <a href="/assessment.php">Take the assessment</a>.</p></div>
<?php include __DIR__ . '/../app/partials/footer.php'; exit; endif;

// load careers
$careers = $pdo->query("SELECT * FROM careers")->fetchAll();

$interests = json_decode($assess['interests'] ?? '[]', true) ?: [];
$skills = json_decode($assess['skills'] ?? '[]', true) ?: [];
$personality = $assess['personality'] ?? 'balanced';


// Try AI service first
$ai_scores = ai_predict_scores($assess, $careers);
if ($ai_scores !== null) {
    $scores = [];
    foreach ($careers as $idx=>$c) {
        $score = (int)round($ai_scores[$idx]*100);
        if ($score < 0) $score = 0;
        if ($score > 100) $score = 100;
        $scores[$c['id']] = $score;
    }
} else {
    // fallback: rule-based
    $scores = [];
    foreach ($careers as $c) {
        $tags = json_decode($c['tags'], true) ?: [];
        $reqskills = json_decode($c['skills_required'], true) ?: [];
        $score = 0;
        foreach ($interests as $i) { if (in_array($i, $tags)) $score += 20; }
        foreach ($skills as $s) { if (in_array($s, $reqskills)) $score += 15; }
        if (in_array($personality, $tags)) $score += 10;
        if ($score > 100) $score = 100;
        $scores[$c['id']] = $score;
    }
}

$scores = [];
foreach ($careers as $c) {
    $tags = json_decode($c['tags'], true) ?: [];
    $reqskills = json_decode($c['skills_required'], true) ?: [];
    $score = 0;
    // interest overlap
    foreach ($interests as $i) { if (in_array($i, $tags)) $score += 20; }
    // skill overlap
    foreach ($skills as $s) { if (in_array($s, $reqskills)) $score += 15; }
    // personality rough fit
    if (in_array($personality, $tags)) $score += 10;
    // normalize clamp
    if ($score > 100) $score = 100;
    $scores[$c['id']] = $score;
}

// sort by score desc
arsort($scores);
$top = array_slice($scores, 0, 5, true);

// store recommendations snapshot
$pdo->beginTransaction();
$pdo->prepare("DELETE FROM recommendations WHERE user_id=?")->execute([$uid]);
$ins = $pdo->prepare("INSERT INTO recommendations(user_id, career_id, score) VALUES(?,?,?)");
foreach ($top as $cid=>$score) { $ins->execute([$uid, $cid, $score]); }
$pdo->commit();

// reload joined
$st = $pdo->prepare("SELECT r.score, c.* FROM recommendations r JOIN careers c ON c.id=r.career_id WHERE r.user_id=? ORDER BY r.score DESC");
$st->execute([$uid]);
$list = $st->fetchAll();
?>
<div class="card">
  <h1>Your Recommendations</h1>
  <div class="grid">
  <?php foreach ($list as $row): ?>
    <div class="card">
      <h3><?=htmlspecialchars($row['title'])?></h3>
      <p class="muted"><?=htmlspecialchars($row['short_desc'])?></p>
      <p><span class="badge"><?=$row['score']?>% match</span></p>
      <details>
        <summary>More details</summary>
        <p><strong>Required skills:</strong> <?=htmlspecialchars(implode(', ', json_decode($row['skills_required'], true) ?: []))?></p>
        <?php $lm = labor_get_stats($row['title']); ?>
        <p><strong>Median salary:</strong> <?= $lm['median_salary'] ? ('$'.number_format($lm['median_salary'])) : '—' ?> · <strong>Demand:</strong> <?= htmlspecialchars($lm['trend'] ?? '—') ?></p>
        <p><strong>Typical roles:</strong> <?=htmlspecialchars($row['roles'])?></p>
        <p><strong>Education:</strong> <?=htmlspecialchars($row['education'])?></p>
        <p><strong>Growth:</strong> <?=htmlspecialchars($row['growth'])?></p>
      </details>
      <form method="post" action="/submit_feedback.php" style="margin-top:10px">
        <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
        <input type="hidden" name="career_id" value="<?=$row['id']?>">
        <label>Rate this suggestion (1-5)</label>
        <select name="rating">
          <option>5</option><option>4</option><option>3</option><option>2</option><option>1</option>
        </select>
        <label>Comment (optional)</label>
        <input name="comment" placeholder="Why did you rate it so?">
        <button type="submit">Submit feedback</button>
      </form>
    </div>
  <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

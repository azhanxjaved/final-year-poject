<?php
require __DIR__ . '/../app/config.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $uid = $_SESSION['user']['id'];
    $career_id = (int)($_POST['career_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    if ($career_id && $rating >=1 && $rating <=5) {
        $st = $pdo->prepare("INSERT INTO feedback(user_id, career_id, rating, comment) VALUES(?,?,?,?)");
        $st->execute([$uid, $career_id, $rating, $comment]);
    }
}
header("Location: /recommendations.php");

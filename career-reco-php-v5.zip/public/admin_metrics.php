<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die('Forbidden'); }

$load = function_exists('sys_getloadavg') ? sys_getloadavg() : [null,null,null];

$mem_total = $mem_free = $mem_avail = null;
if (is_readable('/proc/meminfo')) {
    $mi = file('/proc/meminfo', FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
    $kv = [];
    foreach ($mi as $line) { list($k,$v) = array_map('trim', explode(':', $line, 2)); $kv[$k]=$v; }
    $mem_total = $kv['MemTotal'] ?? null;
    $mem_free = $kv['MemFree'] ?? null;
    $mem_avail = $kv['MemAvailable'] ?? null;
}

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Admin · System Metrics</h1>
  <p><strong>Load avg:</strong> <?=htmlspecialchars(json_encode($load))?></p>
  <p><strong>Memory:</strong> total=<?=$mem_total?> free=<?=$mem_free?> avail=<?=$mem_avail?></p>
  <p class="muted">Values are OS-dependent. For production, use Prometheus + Grafana.</p>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

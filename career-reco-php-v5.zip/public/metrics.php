<?php
require __DIR__ . '/../app/config.php';
header('Content-Type: text/plain; version=0.0.4');
// simple counters from DB
$u = $pdo->query("SELECT COUNT(*) c FROM users")->fetch()['c'];
$a = $pdo->query("SELECT COUNT(*) c FROM assessments")->fetch()['c'];
$r = $pdo->query("SELECT COUNT(*) c FROM recommendations")->fetch()['c'];
$f = $pdo->query("SELECT COUNT(*) c FROM feedback")->fetch()['c'];
echo "app_users_total ".$u."\n";
echo "app_assessments_total ".$a."\n";
echo "app_recommendations_total ".$r."\n";
echo "app_feedback_total ".$f."\n";

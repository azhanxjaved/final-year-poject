<?php
require __DIR__ . '/../app/config.php';
require_login();

// simple stats
$uid = $_SESSION['user']['id'];
$pdo->prepare("UPDATE users SET last_login=NOW() WHERE id=?")->execute([$uid]);

$st = $pdo->prepare("SELECT COUNT(*) c FROM assessments WHERE user_id=?");
$st->execute([$uid]);
$assess_count = (int)$st->fetch()['c'];

$st = $pdo->prepare("SELECT COUNT(*) c FROM recommendations WHERE user_id=?");
$st->execute([$uid]);
$reco_count = (int)$st->fetch()['c'];

include __DIR__ . '/../app/partials/header.php';
?>
<div class="grid">
  <div class="card">
    <h2>Welcome, <?=htmlspecialchars($_SESSION['user']['name'])?></h2>
    <p class="muted">Get personalized career suggestions based on your interests and skills.</p>
    <a class="btn" href="/assessment.php">Start/Update Assessment</a>
  </div>
  <div class="card">
    <h3>Your stats</h3>
    <p><span class="badge"><?=$assess_count?> assessments</span></p>
    <p><span class="badge"><?=$reco_count?> recommendations</span></p>
  </div>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

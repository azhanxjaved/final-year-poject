<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die("Forbidden"); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $text = trim($_POST['text'] ?? '');
    $category = trim($_POST['category'] ?? 'interest');
    $tag = trim($_POST['tag'] ?? '');
    $weight = (int)($_POST['weight'] ?? 1);
    $type = trim($_POST['type'] ?? 'likert');
    $options = trim($_POST['options_json'] ?? '');
    if ($text && $tag) {
        $st = $pdo->prepare("INSERT INTO questions(text,category,tag,weight,type,options_json) VALUES(?,?,?,?,?,?)");
        $st->execute([$text,$category,$tag,$weight,$type, $options ? $options : null]);
    }
    header("Location: /admin_questions.php");
    exit;
}

$rows = $pdo->query("SELECT * FROM questions ORDER BY id DESC")->fetchAll();

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Admin · Questions</h1>
  <form method="post" class="card">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <label>Question text</label><input name="text" required>
    <label>Category</label>
    <select name="category">
      <option value="interest">interest</option>
      <option value="trait">trait</option>
      <option value="skill">skill</option>
    </select>
    <label>Tag (e.g., programming, data, analytical)</label><input name="tag" required>
    <label>Weight</label><input type="number" name="weight" value="1" min="1" max="5">
    <label>Type</label>
    <select name="type">
      <option value="likert">likert</option>
      <option value="single">single</option>
      <option value="multi">multi</option>
    </select>
    <label>Options JSON (for single/multi)</label>
    <input name="options_json" placeholder='["A","B","C"]'>
    <button type="submit">Add question</button>
  </form>

  <h2>Existing questions</h2>
  <table class="table">
    <tr><th>ID</th><th>Text</th><th>Cat</th><th>Tag</th><th>Weight</th><th>Type</th></tr>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?=$r['id']?></td>
        <td><?=htmlspecialchars($r['text'])?></td>
        <td><?=htmlspecialchars($r['category'])?></td>
        <td><?=htmlspecialchars($r['tag'])?></td>
        <td><?=$r['weight']?></td>
        <td><?=htmlspecialchars($r['type'])?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

<?php
require __DIR__ . '/../app/config.php';
require_login();

// save/resume state
$uid = $_SESSION['user']['id'];
$ss = $pdo->prepare("SELECT * FROM assessment_sessions WHERE user_id=?");
$ss->execute([$uid]);
$sessionRow = $ss->fetch();
if ($sessionRow && empty($_SESSION['quiz'])) {
  $_SESSION['quiz'] = json_decode($sessionRow['state_json'], true) ?: [];
  if (isset($sessionRow['page'])) $_GET['page'] = $sessionRow['page'];
}


// Load questions
$qs = $pdo->query("SELECT * FROM questions ORDER BY id ASC")->fetchAll();
$total = count($qs);
if ($total === 0) {
    include __DIR__ . '/../app/partials/header.php';
    echo '<div class="card"><p>No questions found. Admin can add some in Admin · Questions.</p></div>';
    include __DIR__ . '/../app/partials/footer.php';
    exit;
}

$pageSize = 4;
$pages = max(1, ceil($total / $pageSize));
$page = max(1, min($pages, (int)($_GET['page'] ?? 1)));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save'])) {
        if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
        $uid = $_SESSION['user']['id'];
        $state = json_encode($_SESSION['quiz'] ?? []);
        $st = $pdo->prepare("INSERT INTO assessment_sessions(user_id, state_json, page) VALUES (?,?,?) ON DUPLICATE KEY UPDATE state_json=VALUES(state_json), page=VALUES(page)");
        $st->execute([$uid, $state, $page]);
        header("Location: /assessment_quiz.php?page=$page"); exit;
    } elseif (isset($_POST['discard'])) {
        $uid = $_SESSION['user']['id'];
        $pdo->prepare("DELETE FROM assessment_sessions WHERE user_id=?")->execute([$uid]);
        unset($_SESSION['quiz']);
        header("Location: /assessment_quiz.php?page=1"); exit;
    }
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    foreach ($_POST as $k=>$v) {
        if (strpos($k, 'q_') === 0) {
            $_SESSION['quiz'][$k] = (int)$v;
        }
    }
    if (isset($_POST['next'])) {
        $next = min($pages, $page+1);
        header("Location: /assessment_quiz.php?page=$next");
        exit;
    } elseif (isset($_POST['prev'])) {
        $prev = max(1, $page-1);
        header("Location: /assessment_quiz.php?page=$prev");
        exit;
    } elseif (isset($_POST['finish'])) {
        // compute scores
        $answers = $_SESSION['quiz'] ?? [];
        $uid = $_SESSION['user']['id'];
        // create assessment row
        $pdo->beginTransaction();
        $st = $pdo->prepare("INSERT INTO assessments(user_id, interests, skills, personality, goals) VALUES (?,?,?,?,?)");
        $empty = json_encode([]);
        $st->execute([$uid, $empty, $empty, 'balanced', '']);
        $aid = $pdo->lastInsertId();

        // aggregate
        $tagScores = [];
        foreach ($qs as $q) {
            $qid = $q['id'];
            $val = (int)($answers['q_'.$qid] ?? 0); // 1..5
            if ($val) {
                $score = $val * (int)$q['weight'];
                $tag = $q['tag'];
                $tagScores[$tag] = ($tagScores[$tag] ?? 0) + $score;
                // store answer
                $ins = $pdo->prepare("INSERT INTO assessment_answers(assessment_id, question_id, answer, score) VALUES (?,?,?,?)");
                $ins->execute([$aid, $qid, (string)$val, $score]);
            }
        }

        // derive interests (top 3 non-trait/skill tags)
        $nonTraitSkill = array_filter($qs, function($q){ return in_array($q['category'], ['interest']); });
        $interestTags = [];
        foreach ($nonTraitSkill as $q) { $interestTags[$q['tag']] = $tagScores[$q['tag']] ?? 0; }
        arsort($interestTags);
        $topInterests = array_slice(array_keys($interestTags), 0, 3);

        // derive skills (tags from skill category with high score)
        $skillQs = array_filter($qs, function($q){ return $q['category']==='skill'; });
        $skillTags = [];
        foreach ($skillQs as $q) { $skillTags[$q['tag']] = $tagScores[$q['tag']] ?? 0; }
        arsort($skillTags);
        $topSkills = array_slice(array_keys($skillTags), 0, 3);

        // derive personality (max of trait tags)
        $traitQs = array_filter($qs, function($q){ return $q['category']==='trait'; });
        $traitScores = [];
        foreach ($traitQs as $q) { $traitScores[$q['tag']] = $tagScores[$q['tag']] ?? 0; }
        arsort($traitScores);
        $personality = count($traitScores)? array_keys($traitScores)[0] : 'balanced';

        // update assessment row
        $upd = $pdo->prepare("UPDATE assessments SET interests=?, skills=?, personality=? WHERE id=?");
        $upd->execute([json_encode(array_values($topInterests)), json_encode(array_values($topSkills)), $personality, $aid]);
        $pdo->commit();

        unset($_SESSION['quiz']);
        header("Location: /recommendations.php?from=quiz");
        exit;
    }
}

$startIdx = ($page-1)*$pageSize;
$subset = array_slice($qs, $startIdx, $pageSize);

$progress = intval(($page/$pages)*100);

include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Assessment</h1>
  <div style="background:#1b1f2a;border-radius:999px;overflow:hidden;height:10px;margin:10px 0 20px">
    <div style="height:100%;width: <?=$progress?>%; background:#2b7fff;"></div>
  </div>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <?php foreach ($subset as $q): 
      $qid = $q['id'];
      $saved = $_SESSION['quiz']['q_'.$qid] ?? '';
    ?>
      <div class="card">
        <label><strong><?=htmlspecialchars($q['text'])?></strong> <span class="badge"><?=htmlspecialchars($q['category'])?> · <?=htmlspecialchars($q['tag'])?></span></label>
        <div>
          <?php for ($i=1; $i<=5; $i++): ?>
            <label style="margin-right:10px">
              <input type="radio" name="q_<?=$qid?>" value="<?=$i?>" <?=($saved==$i?'checked':'')?>>
              <?=$i?>
            </label>
          <?php endfor; ?>
          <span class="muted">1=Strongly disagree, 5=Strongly agree</span>
        </div>
      </div>
    <?php endforeach; ?>
    <div style="display:flex;gap:8px">
      <?php if ($page>1): ?><button name="prev" value="1" type="submit">Previous</button><?php endif; ?>
      <?php if ($page<$pages): ?><button name="next" value="1" type="submit">Next</button><?php else: ?>
        <button name="finish" value="1" type="submit">Finish</button>
      <?php endif; ?>
    </div>
  <div style="margin-left:8px"><button name="save" value="1" type="submit">Save</button> <button name="discard" value="1" type="submit">Discard</button></div>
</form>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

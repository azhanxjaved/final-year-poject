<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/audit.php';

$token = $_GET['token'] ?? '';
if ($token) {
    $st = $pdo->prepare("SELECT user_id, expires_at, used FROM email_verifications WHERE token=?");
    $st->execute([$token]);
    $row = $st->fetch();
    if ($row && !$row['used'] && strtotime($row['expires_at']) > time()) {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE users SET email_verified=1 WHERE id=?")->execute([$row['user_id']]);
        $pdo->prepare("UPDATE email_verifications SET used=1 WHERE token=?")->execute([$token]);
        $pdo->commit();
        audit_log($pdo, 'verify_ok', ['uid'=>$row['user_id']]);
        echo "Email verified. You can close this window.";
        exit;
    }
}
http_response_code(400);
echo "Invalid or expired token.";

<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/audit.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    $role = 'user';
    if (!$name || !$email || !$pass) { $err = "All fields are required."; }
    else {
        // check duplicate
        $st = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $st->execute([$email]);
        if ($st->fetch()) { $err = "Email already in use."; }
        else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $st = $pdo->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)");
            $st->execute([$name,$email,$hash,$role]);
            audit_log($pdo, 'register', ['email'=>$email]);
            header("Location: /login.php?new=1");
            exit;
        }
    }
}
include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Create Account</h1>
  <?php if (!empty($err)): ?><p class="muted"><?=$err?></p><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <label>Full Name</label>
    <input name="name" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password</label>
    <input type="password" name="password" minlength="8" required>
    <div style="margin-top:12px"><button type="submit">Sign up</button></div>
  </form>
  <p class="muted">Already have an account? <a href="/login.php">Login</a></p>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>

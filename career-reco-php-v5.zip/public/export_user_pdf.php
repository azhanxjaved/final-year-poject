<?php
require __DIR__ . '/../app/config.php';
require_login();
if (!is_admin()) { http_response_code(403); die('Forbidden'); }
require __DIR__ . '/../vendor/fpdf/fpdf.php';

$uid = (int)($_GET['user_id'] ?? 0);
if (!$uid) { http_response_code(400); die('user_id required'); }

$u = $pdo->prepare("SELECT name,email FROM users WHERE id=?");
$u->execute([$uid]);
$user = $u->fetch();
if (!$user) { http_response_code(404); die('User not found'); }

$ass = $pdo->prepare("SELECT * FROM assessments WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
$ass->execute([$uid]);
$assessment = $ass->fetch();

$recs = $pdo->prepare("SELECT r.score, c.* FROM recommendations r JOIN careers c ON c.id=r.career_id WHERE r.user_id=? ORDER BY r.score DESC");
$recs->execute([$uid]);
$reclist = $recs->fetchAll();

$interests = $assessment ? (json_decode($assessment['interests'] ?? '[]', true) ?: []) : [];
$skills = $assessment ? (json_decode($assessment['skills'] ?? '[]', true) ?: []) : [];
$personality = $assessment['personality'] ?? '—';
$today = date('Y-m-d H:i');

$pdf = new FPDF('P','mm','A4');
$pdf->SetTitle('Career Report', true);
$pdf->SetAuthor('CareerRec', true);
$pdf->AddPage();
$pdf->SetFont('Helvetica','',16);
$pdf->Cell(0,10,'Career Report',0,1);
$pdf->SetFont('Helvetica','',11);
$pdf->Cell(0,6,'Name: ' . ($user['name'] ?? '—'),0,1);
$pdf->Cell(0,6,'Email: ' . ($user['email'] ?? '—'),0,1);
$pdf->Cell(0,6,'Generated: ' . $today,0,1);
$pdf->Ln(4);

$pdf->SetFont('Helvetica','',13);
$pdf->Cell(0,8,'Assessment Summary',0,1);
$pdf->SetFont('Helvetica','',11);
$pdf->Cell(0,6,'Interests: ' . implode(', ', $interests),0,1);
$pdf->Cell(0,6,'Skills: ' . implode(', ', $skills),0,1);
$pdf->Cell(0,6,'Personality: ' . $personality,0,1);
$pdf->Ln(4);

$pdf->SetFont('Helvetica','',13);
$pdf->Cell(0,8,'Top Recommendations',0,1);
$pdf->SetFont('Helvetica','',11);
if (!$reclist) {
    $pdf->Cell(0,6,'No recommendations available for this user.',0,1);
} else {
    foreach ($reclist as $row) {
        $line = sprintf('%s — %d%% match', $row['title'], (int)$row['score']);
        $pdf->Cell(0,6,$line,0,1);
        if (!empty($row['short_desc'])) $pdf->Cell(0,6,'  ' . $row['short_desc'],0,1);
        $pdf->Cell(0,6,'  Required: ' . implode(', ', json_decode($row['skills_required'] ?? '[]', true) ?: []),0,1);
        $pdf->Ln(2);
    }
}
$pdf->Output('I', 'career_report_'.$uid.'.pdf', true);

<?php
require __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/email.php';
require_once __DIR__ . '/../app/audit.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid CSRF'); }
    $email = trim($_POST['email'] ?? '');
    $st = $pdo->prepare("SELECT id FROM users WHERE email=?");
    $st->execute([$email]);
    if ($u = $st->fetch()) {
        $token = create_password_reset($pdo, $u['id']);
        $link = (isset($_SERVER['HTTPS'])?'https':'http')."://".$_SERVER['HTTP_HOST']."/reset.php?token=".$token;
        send_mail_simple($email, "Password reset", "Reset your password: ".$link);
        audit_log($pdo, 'reset_sent', ['email'=>$email]);
    }
    $msg = "If the email exists, a reset link has been sent.";
}
include __DIR__ . '/../app/partials/header.php';
?>
<div class="card">
  <h1>Forgot Password</h1>
  <?php if (!empty($msg)): ?><p><?=$msg?></p><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
    <label>Email</label><input type="email" name="email" required>
    <button type="submit">Send reset link</button>
  </form>
</div>
<?php include __DIR__ . '/../app/partials/footer.php'; ?>
